from inf5860.classifiers.k_nearest_neighbor import *
from inf5860.classifiers.linear_classifier import *
